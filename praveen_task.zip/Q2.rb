str = gets.chomp 
if str.length>10
  str = str.upcase
end
puts str
