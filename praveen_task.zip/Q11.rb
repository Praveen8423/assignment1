puts "Enter First Name : "
f_name = gets.chomp
puts "Enter Middle Name : "
m_name = gets.chomp
puts "Enter Last Name : "
l_name = gets.chomp
puts "#{f_name[0]}.#{m_name[0]}.#{l_name}"