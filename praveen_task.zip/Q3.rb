puts "How old are you : "
age = gets.chomp.to_i
puts "\nYour age after 10 years will be : #{age+10}"
puts "Your age after 20 years will be : #{age+20}"
puts "Your age after 30 years will be : #{age+30}"
puts "Your age after 40 years will be : #{age+40}"